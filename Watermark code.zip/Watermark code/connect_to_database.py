import mysql.connector as mysql
def connect():
	# conn=mysql.connect('localhost','kali','kali','wmking')
	conn=mysql.connect(host='localhost', user='kali', password='kali', database='wmking')
	return conn


def close(conn):
	conn.close()
