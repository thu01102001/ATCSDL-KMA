import connect_to_database
import print_from_table
import hashlib
import model
import sys
def list():
	conn=connect_to_database.connect()
	rows=model.fetch_everything_from_table(conn,'data')
	connect_to_database.close(conn)
	return render_template('test.html',rows = rows)


def copy_data_from_src_to_dest(src,dest):
	conn=connect_to_database.connect()
	model.delete_everything_table(conn,dest)
	param=model.fetch_a_b_c_from_table(conn,src)
	model.insert_param_into_table(conn,dest,param)
	print('\nTable2 is ready!')
	connect_to_database.close(conn)


def update():
	conn=connect_to_database.connect()
	rows=model.fetch_everything_from_table(conn,'data2')
	connect_to_database.close(conn)
	return render_template('test.html',rows = rows)

def check_id(id):
	m=hashlib.md5()
	m.update('thisIsSecretKey')
	m.update(str(id))
	return int(m.hexdigest(),27)

import bitstring
def watermark(table_name):
	conn=connect_to_database.connect()
	count=0
	params=[]

	v = 3
	e = 16
	m = 11
	for i in range(1,10000):
		attr_position=[]
		if check_id(i)%m == 0:
			count += 1
			attr = check_id(i) % v
			posi = check_id(i) % e

			rows = model.fetch_only_a_b_c_from_table(conn,table_name,i)
			for row in rows:
				attr_position.append(row)
			choose = bitstring.BitArray(float=float(attr_position[attr]), length=32)
			binary = choose.bin
			# print(i)
			if check_id(i)%2 == 0:				
				new_binary = binary[:posi] + '1' + binary[posi+1:]
			else:
				new_binary = binary[:posi] + '0' + binary[posi+1:]
			new_float = bitstring.BitArray(bin=new_binary)
			new_float = new_float.floatbe
			attr_position[attr] = new_float
			attr_position.append(i)
			params.append(tuple(attr_position))
	model.update_all_a_b_c_in_table(conn,table_name,params)			

	print "\nTotal rows Updated %d"%count
	connect_to_database.close(conn)	

def reverse_watermark(table_name):
	conn=connect_to_database.connect()
	match=0
	params=[]

	v = 3
	e = 16
	m = 11
	for i in range(1,10000):
		attr_position=[]
		if check_id(i)%m == 0:
			attr = check_id(i) % v
			posi = check_id(i) % e

			rows = model.fetch_only_a_b_c_from_table(conn,table_name,i)
			for row in rows:
				attr_position.append(row)
			choose = bitstring.BitArray(float=float(attr_position[attr]), length=32)
			binary = choose.bin
			if check_id(i)%2 == 0:				
				if binary[posi] == '1':
					match += 1
			else:
				if binary[posi] == '0':
					match += 1
			
	print "\nTotal tuples match %d"%match
	connect_to_database.close(conn)		


def count_similarity(list1,list2):
	count=0;
	#print list1
	#print list2
	for i in range(0,9999):
		if (int(list1[i][0])==int(list2[i][0]))&(int(list1[i][1])==int(list2[i][1]))&(int(list1[i][2])==int(list2[i][2])):
			count+=1
			#print i+1

	per=(float(count)/9999)*100
	ans=9999-count
	return per		

def compare_tables(src,dest):
	conn=connect_to_database.connect()
	list1=model.fetch_a_b_c_from_table(conn,src)
	list2=model.fetch_a_b_c_from_table(conn,dest)
	ans = count_similarity(list1,list2)
	print('Similar: ' + str(ans))

if __name__ == '__main__':
	while True:
		text=int(raw_input('''---------------------------\nEnter 1 for refershing table_2
Enter 2 for watermarking table_2
Enter 3 for comparing original and watermarked table
Enter 4 for compute number of tuple changed\n---------------------------\nChoose number: '''))
		if text == 1:
			copy_data_from_src_to_dest('data','data2')
		elif text==2:
			watermark('data2')
		elif text==3:
			compare_tables('data','data2')
		elif text==4:
			reverse_watermark('data2')	
		else:
			break		

	
